Task 3: SQL for Data Analysis

Included Files:
- ecommerce_sample.db : Sample SQLite database with e-commerce data.
- task3_queries.sql : SQL queries used to analyze the data.


Queries Included:
Total sales by category
Top 5 products by revenue
Customer orders and spend
Monthly sales trend
Orders without payment
View creation for reuse
